<?php
$logPath='/var/log/pi-star';
$callsign='BI3BDH';
$registerURL = '';
$starLogPath = $logPath . '/STARnet.log';
$linkLogPath = $logPath . '/Links.log';
$hdrLogPath = $logPath . '/Headers.log';
$ddmode_log = $logPath . '/DDMode.log';
$configPath='/etc';
$gatewayConfigPath = '/etc/ircddbgateway';
$defaultConfPath = '/etc/default';
$sharedFilesPath = '/usr/local/etc';
$sysConfigPath = '/etc/sysconfig';
?>

